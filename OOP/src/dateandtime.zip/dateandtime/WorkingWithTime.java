package dateandtime;

import java.time.LocalTime;
public class WorkingWithTime {
    public static void main(String[] args){
        LocalTime time = LocalTime.now();
        LocalTime myTime = LocalTime.of(12, 23, 34);
        System.out.printf("%s%n", time);
        System.out.printf("%s%n", myTime);
        
        // methods
        System.out.println(time.getHour());
        System.out.println(time.getNano());
       
    }
}
